import sqlite.*;
import java.util.*;

/** Simple test for the sqlite package.
 *
 * <p><code>$Revision: 1.1 $</code><br />
 * <code>$Date: 2004/04/09 18:58:36 $</code><br />
 * <code>$Author: cvs $</code></p>
 */
public class testit {
    public static void main(String[] args)
    {
	System.out.println("Using the class interface:");
	useclass();

	//System.loadLibrary("SqliteDB_java");

	SqliteDB db = DB.Open("test.db");
	SqliteQuery q = DB.MakeQuery(db,
	   "select * from fortune where fort_num >= 42 and fort_num <= 50 order by fort_num;");

	while (DB.Fetch(q) == DB.SQLITE_ROW) {
	    int cc = DB.ColumnCount(q);
	    String r = "";
	    for (int i = 0; i < cc; i++) {
		String v = DB.ColumnValue(q, i);
		r +=  v + ";";
	    }
	    System.out.println(r);
	}

	DB.EndQuery(q);
	DB.Close(db);

    }

    static void useclass()
    {
	Sqlite db = new Sqlite("../sqlite_wrapper/fortune.db");
	db.open();
	if (!db.is_valid()) {
	    System.out.println("Open failed: "+db.last_error());
	    return;
	}
	String querystr = "select * from fortune where fort_num >= @min@ and fort_num <= @max@ order by fort_num;";
	Properties p = new Properties();
	p.setProperty("min", String.valueOf(42));
	p.setProperty("max", String.valueOf(50));
	querystr = Sqlite.format_statement(querystr, p);
	System.out.println("Statement: "+querystr);
	Query q = db.make_query(querystr);

	if (q == null) {
	    System.out.println("Query failed: "+db.last_error());
	    return;
	}

	Row r;
	while ((r = q.fetch_row()) != null) {
	    int n = r.size();
	    String[] v = r.values();
	    for (int i = 0; i < n; i++) {
		System.out.print(v[i]+";");
	    }
	    System.out.println("");
	}
	q.finish();
	db.close();
    }
}
