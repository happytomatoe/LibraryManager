#!/usr/bin/perl -w

use strict;
use File::Glob ':glob';
use FileHandle;

if (scalar(@ARGV) != 1) {
    print STDERR "usage: $0 directory\n";
    exit 1;
}

my @files = bsd_glob($ARGV[0]."/*.java");
foreach (@files) { process_file($_); }

exit 0;

sub process_file {
    my $fname = shift;
    my $outname = "$fname.out";
    my $bakname = "$fname.bak";
    my $newname = $fname;
    $newname =~ s/SWIGTYPE_p_//g;

    print "INFILE:  $fname; renaming SWIGTYPE_p_ occurrences\n";
    print "OUTFILE: $newname\n";
    my $infh = new FileHandle("<$fname");
    my $outfh = new FileHandle(">$outname");

    while (<$infh>) {
	s/SWIGTYPE_p_//g;
	print $outfh $_;
    }
    $infh->close();
    $outfh->close();

    unlink($bakname) if (-f $bakname);
    rename($fname, $bakname);
    rename($outname, $newname);
}
