/* $Id: sqlitewrapper.h,v 1.2 2004/04/12 18:24:37 cvs Exp $ */
/* $Date: 2004/04/12 18:24:37 $ */

#ifndef sqlitewrapper_dot_h_
#define sqlitewrapper_dot_h_

#ifdef __cplusplus
extern "C" {
#endif

typedef struct SqliteDB SqliteDB;
typedef struct SqliteQuery SqliteQuery;

SqliteDB *SqliteOpen(const char *fname);
int SqliteIsValid(const SqliteDB *);
const char *SqliteLastError(const SqliteDB *);

void SqliteClose(SqliteDB *);

int SqliteExec(SqliteDB *, const char *);
int SqliteChanges(SqliteDB *);

SqliteQuery *SqliteMakeQuery(SqliteDB *, const char *);
void SqliteEndQuery(SqliteQuery *);

void SqliteSetBusyTimeout(SqliteDB *, int);

int SqliteFetch(SqliteQuery *);
int SqliteColumnCount(const SqliteQuery *);
int SqliteRowNumber(const SqliteQuery *);
const char *SqliteColumnName(const SqliteQuery *, int);
const char *SqliteColumnType(const SqliteQuery *, int);
const char *SqliteColumnValue(const SqliteQuery *, int);

#ifdef __cplusplus
}
#endif

#endif
