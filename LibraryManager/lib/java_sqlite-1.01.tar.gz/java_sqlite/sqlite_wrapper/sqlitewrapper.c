/* $Id: sqlitewrapper.c,v 1.2 2004/04/12 18:24:37 cvs Exp $ */
/* $Date: 2004/04/12 18:24:37 $ */

#include <stdio.h>
#include <malloc.h>
#include "sqlite.h"
#include "sqlitewrapper.h"

struct SqliteDB {
    sqlite *db;
    char   *last_error;
};

static void clear_error(SqliteDB *obj)
{
    if (obj && obj->last_error) {
	sqlite_freemem(obj->last_error);
	obj->last_error = 0;
    }
}

SqliteDB *SqliteOpen(const char *fname)
{
    SqliteDB *obj = malloc(sizeof(SqliteDB));
    if (!obj) return 0;

    obj->last_error = 0;
    obj->db = sqlite_open(fname, 0644, &(obj->last_error));
    return obj;
}

int SqliteIsValid(const SqliteDB *obj)
{
    return obj && obj->db;
}

const char *SqliteLastError(const SqliteDB *obj)
{
    return (obj ? obj->last_error : "");
}

void SqliteClose(SqliteDB *obj)
{
    if (obj) {
	clear_error(obj);
	if (obj->db) sqlite_close(obj->db);
	obj->db = 0;
	free(obj);
    }
}

static int bogus_callback(void *pArg, int nArg, char **azArg, char **azCol){
    return 0;
}

void SqliteSetBusyTimeout(SqliteDB *obj, int ms)
{
    sqlite_busy_timeout(obj->db, ms);
}

int SqliteExec(SqliteDB *obj, const char *stmt)
{
    int r = 0;
    //fprintf(stderr, "Statment: <%s>\n", stmt);
    if (!SqliteIsValid(obj)) return SQLITE_MISUSE;
    //fprintf(stderr, "calling sqlite_exec...\n");
    clear_error(obj);
    r = sqlite_exec(obj->db, stmt, bogus_callback, 0, &(obj->last_error));
    //fprintf(stderr, "Result: %d, last error: <%s>\n", r, 
    //   (obj->last_error? obj->last_error : "null"));
    return r;
}

int SqliteChanges(SqliteDB *obj)
{
    if (!SqliteIsValid(obj)) return -1;
    return sqlite_changes(obj->db);
}

struct SqliteQuery {
    char     **colnames;
    char     **colvalues;
    int        numcols;
    int        rowcount;
    sqlite_vm *vm;
};

SqliteQuery *SqliteMakeQuery(SqliteDB *obj, const char *stmt)
{
    SqliteQuery *query = 0;
    int r = 0;
    const char *tail = 0;

    if (!SqliteIsValid(obj)) return query;
    if (!stmt) return query;
    clear_error(obj);

    query = malloc(sizeof(SqliteQuery));
    if (!query) return 0;

    query->colnames = query->colvalues = 0;
    query->vm = 0;
    query->numcols = query->rowcount = 0;

    r = sqlite_compile(obj->db, 
		       stmt,
		       &tail,
		       &(query->vm),
		       &(obj->last_error));
    if (r != SQLITE_OK) {
	char *p = 0;
	if (query->vm) sqlite_finalize(query->vm, &p);
	if (p) sqlite_freemem(p);
	free(query);
	return 0;
    }
    return query;
}

void SqliteEndQuery(SqliteQuery *query)
{
    if (query) {
	char *p = 0;
	sqlite_finalize(query->vm, &p);
	if (p) sqlite_freemem(p);
	query->vm = 0;
	free(query);
    }
}

int SqliteFetch(SqliteQuery *query)
{
    int r = 0;
    if (!query || !query->vm) return SQLITE_MISUSE;
    r = sqlite_step(query->vm, &(query->numcols),
		    (const char ***)&(query->colvalues), 
		    (const char ***)&(query->colnames));
    if (r == SQLITE_ROW) query->rowcount++;
    return r;
}

int SqliteRowNumber(const SqliteQuery *query)
{
    return query ? query->rowcount : -1;
}

int SqliteColumnCount(const SqliteQuery *query)
{
    if (!query || !query->rowcount) return -1;
    return query->numcols;
}

const char *SqliteColumnName(const SqliteQuery *query, int n)
{
    if (!query || !query->rowcount || n >= query->numcols || n < 0) 
	return 0;
    return query->colnames[n];
}

const char *SqliteColumnType(const SqliteQuery *query, int n)
{
    if (!query || !query->rowcount || n >= query->numcols || n < 0) 
	return 0;
    return query->colnames[n+query->numcols];
}

const char *SqliteColumnValue(const SqliteQuery *query, int n)
{
    if (!query || !query->rowcount || n >= query->numcols || n < 0) 
	return 0;
    return query->colvalues[n];
}
