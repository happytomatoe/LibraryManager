#!/usr/bin/perl -w
#######################################################################
# $RCSfile: test.pl,v $
# $Revision: 1.1 $
# $Date: 2004/04/09 16:22:42 $
# $Author: cvs $

use strict;
use SqliteDBImpl;
use SqliteDB;

print STDERR "SQLITE VERSION:" , $SQLITE_VERSION, "\n";
print STDERR "Using utf8: ", $SQLITE_UTF8, "\n";

unlink("test.db");

my $db = SqliteDBImpl::SqliteOpen("test.db");
if (SqliteDBImpl::SqliteIsValid($db)) {
    print STDERR "DB opened/created.\n";
}
else {
    print STDERR "Error: ", SqliteDBImpl::SqliteLastError($db), "\n";
    SqliteDBImpl::SqliteClose($db);
    exit 1;
}

my $r = SqliteDBImpl::SqliteExec($db, <<_END_CREATE_
create table test_table (
	c1 integer,
	c2 text,
	c3 number
);
_END_CREATE_
)    ;

if ($r != $SQLITE_OK) {
    print STDERR "Error creating table; code: $r; ", SqliteDBImpl::SqliteLastError($db), "\n";
    SqliteDBImpl::SqliteClose($db);
    exit 1;
}

my $q = SqliteDBImpl::SqliteMakeQuery($db, "select * from test_table;");
if (!defined($q)) {
    print STDERR "Error: ", SqliteDBImpl::SqliteLastError($db), "\n";
    SqliteDBImpl::SqliteClose($db);
    exit 1;
}

if (($r = SqliteDBImpl::SqliteFetch($q)) != $SQLITE_DONE) {
    print STDERR "Error: ", SqliteDBImpl::SqliteLastError($db), "\n";
    SqliteDBImpl::SqliteClose($db);
    exit 1;
}

$r = SqliteDBImpl::SqliteExec($db, <<_END_INSERT_
insert into test_table values(1, "fooo bar", 42.666);
_END_INSERT_
			      );
$q = SqliteDBImpl::SqliteMakeQuery($db, "select * from test_table;");
if (!defined($q)) {
    print STDERR "Error: ", SqliteDBImpl::SqliteLastError($db), "\n";
    SqliteDBImpl::SqliteClose($db);
    exit 1;
}

while (($r = SqliteDBImpl::SqliteFetch($q)) != $SQLITE_DONE) {
    if ($r != $SQLITE_ROW) {
	print STDERR "Error: ", SqliteDBImpl::SqliteLastError($db), "\n";
	SqliteDBImpl::SqliteClose($db);
	exit 1;
    }
    my $nc = SqliteDBImpl::SqliteColumnCount($q);
    print STDERR "Column count: ", $nc, "\n";
    for (my $i = 0; $i < $nc; $i++) {
	print STDERR SqliteDBImpl::SqliteRowNumber($q)
	    , "--", SqliteDBImpl::SqliteColumnName($q, $i)
	    , ":", SqliteDBImpl::SqliteColumnType($q, $i),
	    , "=", SqliteDBImpl::SqliteColumnValue($q, $i),"\n";
    }
}

SqliteDBImpl::SqliteClose($db);

print STDERR "--------------------------------------------------\n";
$db = new SqliteDB("test.db");
if (!defined($db->open())) {
    print STDERR "Error opening db\n";
    exit 1;
}

$q = $db->make_query("select * from test_table;");
if (!defined($q)) {
    print STDERR "Error in query:", $db->last_error, "\n";
    exit 1;
}

while (defined(my $row = $q->fetch())) {
    my $nc = $row->size();
    print STDERR "Column count: ", $nc, "\n";
    for (my $i = 0; $i < $nc; $i++) {
	print STDERR $row->number();
	print STDERR  "--", $row->names()->[$i];
	print STDERR  ":", $row->types()->[$i];
	print STDERR  "=", $row->values()->[$i],"\n";
    }
}
$db->close();

exit 0;

