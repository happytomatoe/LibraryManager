#!/usr/bin/perl -w

use strict;
use FileHandle;

my $template  = "SqliteDB.pm.template";
my $output    = "SqliteDB.pm";
my $constfile = "SqliteDB_Constants.i";

my @const_names = ();
my $inp = new FileHandle("<$constfile");
while (defined(my $line = <$inp>)) {
    $line =~ s/^#define\s*//;
    if ($line =~ /^(\S+)/) {
	my $c = $1;
	push @const_names, $c;
    }
}

$inp->close();

$inp = new FileHandle("<$template");
my $out = new FileHandle(">$output");
while (defined(my $line = <$inp>)) {
    if ($line =~ /\#\#sqlite_consts\#\#/) {
	my $repl = "";
	foreach my $c (@const_names) {
	    $repl .= "\n\$$c ";
	}
	$line =~ s/\#\#sqlite_consts\#\#/$repl/;
    }
    elsif ($line =~ /__END__/) {
	foreach my $c (@const_names) {
	    print $out '*', $c,  ' = *SqliteDBImpl::', $c, ";\n";
	}
	print $out "1;\n";
    }
    elsif ($line =~ /\#\#pod_sqlite_consts\#\#/ ) {
	foreach my $c (@const_names) {
	    print $out "\n\n=item \$$c";
	}
        print $out "\n\n";
	$line = "";
    }

    print $out $line;
}
$inp->close();
$out->close();
