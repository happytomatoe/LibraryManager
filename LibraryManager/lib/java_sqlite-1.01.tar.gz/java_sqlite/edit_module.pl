#!/usr/bin/perl -w

use strict;
use FileHandle;

exit 1 if (!scalar(@ARGV));

my $inpname = $ARGV[0];
my $outname = "$inpname.out";

my $infh = new FileHandle("<$inpname");
my $outfh = new FileHandle(">$outname");

print "FILE: $inpname; remove Sqlite prefix from method names.\n";
while (<$infh>) {
    if (/^\s*public\s+/) {
	s/\sSqlite([A-Z][a-z][a-zA-Z]+)\(/ $1\(/g;
    }
    print $outfh $_;
}
$infh->close();
$outfh->close();

my $bakname = "$inpname.bak";
unlink($bakname) if -f $bakname;
rename($inpname, $bakname);
rename($outname, $inpname);
