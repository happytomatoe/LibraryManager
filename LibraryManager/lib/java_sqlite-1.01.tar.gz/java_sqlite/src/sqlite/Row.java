// $Id: Row.java,v 1.1 2004/04/09 19:02:04 cvs Exp $
// $Date: 2004/04/09 19:02:04 $

package sqlite;
import sqlite.*;

/**
 * <p>The result of a query's FETCH call.</p>
 *
 * <p><code>$Revision: 1.1 $</code><br />
 * <code>$Date: 2004/04/09 19:02:04 $</code><br />
 * <code>$Author: cvs $</code></p>
 */
public class Row {
    protected Row(String[] v, String[] nm, String[] t, int n) {
	the_values = v;
	the_names  = nm;
	the_types  = t;
	the_number = n;
    }

    public int size() { return the_values.length; }

    public String[] names() { return the_names; }
    public String[] types() { return the_types; }
    public String[] values() { return the_values; }
    public int number() { return the_number; }

    protected String[] the_values;
    protected String[] the_types;
    protected String[] the_names;
    protected int the_number;
}



