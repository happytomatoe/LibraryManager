// $Id: Query.java,v 1.1 2004/04/09 19:02:04 cvs Exp $
// $Date: 2004/04/09 19:02:04 $

package sqlite;
import sqlite.*;

/**
 * Encapsulates a query object.  Instantiated through a call to
 * {@link sqlite.Sqlite#make_query Sqlite.make_query}.
 *
 * <p><code>$Revision: 1.1 $</code><br />
 * <code>$Date: 2004/04/09 19:02:04 $</code><br />
 * <code>$Author: cvs $</code></p>
 */
public class Query {
    /**
       Constructor.

       @param q native query object.
     */
    protected Query(SqliteQuery q) {
	thequery = q;
    }

    /**
       Low level fetch routine.

       @return native status code (from sqlite_step).
     */
    protected int fetch() { 
	return DB.Fetch(thequery);
    }

    /**
       Returns a row containing one string for each column.
       The return value is null if the query is in error, or
       the result set is exhausted.

       @return one row from the result set, or null.
     */
    public Row fetch_row() { 
	int r = this.fetch();
	if (r != DB.SQLITE_ROW) return null;
	int n = this.col_count();
	String[] values = new String[n];
	int i;
	for (i = 0; i < n; i++) {
	    values[i] = this.col_value(i);
	}

	if (types == null) {
	    types = new String[n];
	    names = new String[n];
	    for (i = 0; i < n; i++) {
		types[i] = this.col_type(i);
		names[i] = this.col_name(i);
	    }
	}
	return new Row(values, names, types, this.row_number());
    }

    /**
       number of the current row (starting at 1).
       @return row number (starting at 1).
     */
    public int row_number() {
	return DB.RowNumber(thequery);
    }

    /**
       Number of columns in each row.  Must have executed at least
       one fetch, or the result will not be valid.

       @return column count in one row.
     */
    public int col_count() { 
	return DB.ColumnCount(thequery);
    }

    /**
       Name of the i'th column (starting at 0).
       Must have executed at least one fetch.

       @return Name of the i'th column (starting at 0).
     */
    public String col_name(int i) { 
	return DB.ColumnName(thequery, i);
    }

    /**
       Database type of the i'th column (starting at 0).
       Must have executed at least one fetch.

       @return database type of the i'th column (starting at 0).
     */
    public String col_type(int i) {
	return DB.ColumnType(thequery, i); 
    }

    /**
       value of the i'th column in the current row, starting at 0.

       @return value of the i'th columnin the current row.
     */
    public String col_value(int i) {
	return DB.ColumnValue(thequery, i);
    }

    /**
       Finalize the query, and relese its resources.
     */
    public void finish() {
	DB.EndQuery(thequery);
	thequery = null;
	types = names = null;
    }

    /**
       native query object.
     */
    protected SqliteQuery thequery = null;

    /**
       column types.
     */
    protected String[] types  = null;

    /**
       column names.
     */
    protected String[] names  = null;
}
