// $Id: Sqlite.java,v 1.2 2004/04/12 18:44:52 cvs Exp $
// $Date: 2004/04/12 18:44:52 $
package sqlite;
import java.util.*;
import sqlite.*;

/**
 * Interface to sqlite, using SWIG.
 *
 * <p>The class {@link sqlite.Sqlite sqlite.Sqlite} provides an abstraction 
 * on top of a SWIG gnerated native interface.</p>
 *
 * <p>The interface is very simple, and consists of the following
 * classes:</p>
 * <ul>
 * <li> {@link sqlite.Sqlite sqlite.Sqlite}: manages access to the
 * database file, execution of SQL statements, and creation of 
 * {@link sqlite.Query queries}.</li>
 * <li> {@link sqlite.Query sqlite.Query}: provides access to query
 * results, one {@link sqlite.Row row} at a time.</li>
 * <li> {@link sqlite.Row sqlite.Row}: encapsulates the row concepts,
 * and provides access to a row's columns (as strings), types, and row
 * number.</li>
 * </ul>
 *
 * <p>The <a href="http://www.swig.org">SWIG</a> interface is based on
 * a small C wrapper module that provides a simple interface, with
 * easily handled interface types (as opposed to the char*** types of
 * the raw SQLITE C API).</p>
 *
 * <p>The <a href="http://www.swig.org">SWIG</a> output is edited,
 * with Perl, to change the names of the generated classes.  The
 * generated classes are: {@link sqlite.DB}, {@link sqlite.DBJNI},
 * {@link sqlite.SqliteDB}, {@link sqlite.SqliteQuery}.</p>
 *
 * <p>The generated classes can be used directly, after loading the
 * system library "SqliteDB_java" (libSqliteDB_java.so or
 * SqliteDB_java.dll), using {@link System#loadLibrary(String)}.</p>
 *
 * <p>Alternatively, the class interface automatically loads the
 * shared library upoing loading the class {@link sqlite.Sqlite}.</p>
 *
 * <p><code>$Revision: 1.2 $</code><br />
 * <code>$Date: 2004/04/12 18:44:52 $</code><br />
 * <code>$Author: cvs $</code></p>
 */
public class Sqlite {
    /**
     * Constructor.
     *
     * @param fname Name of the sqlite database file to use.
     */
    public Sqlite(String fname) {
	filename = fname;
    }

    /**
     * opens the database file.
     *
     * @return self.
     */
    public Sqlite open() {
	thedb = DB.Open(filename);
	return this;
    }

    /**
     * close the database file.
     *
     * @return self.
     */
    public Sqlite close() {
	DB.Close(thedb);
	thedb = null;
	return this;
    }

    /**
     * check for validity of open call.
     *
     * @return true if OK, false otherwise.
     */
    public boolean is_valid() {	
	return DB.IsValid(thedb) != 0;
    }

    /**
     * executes the statement.
     *
     * @param stmt SQL statement to be executed.
     * @return status code of execution.
     *
     * This is suitable for statements that do not return values.
     * To get data from the database, use {@link #make_query make_query}.
     */
    public int exec(String stmt) {
	return DB.Exec(thedb, stmt);
    }

    /**
     * returns the last error message from the database.
     *
     * @return last error message from the database.
     */
    public String last_error() {
	return DB.LastError(thedb);
    }

    /**
     * Sets the waiting time before SQLITE_BUSY is returned.
     *
     * @param ms timeout value in milliseconds.
     *
     * Sets the timeout to ms milliseconds: after setting the timeout to
     * a non-negative value, sqlite will wait for at least <i>ms</i>
     * milliseconds for a lock to clear before returning
     * <code>SQLITE_BUSY</code> (see C<http://www.sqlite.org>).
     *
     * A zero, or negative value of <i>ms</i> will restore default
     * behavior (returns <code>SQLITE_BUSY</code> without waiting).
     */
    public void set_timeout(int ms) {
	DB.SetBusyTimeout(thedb, ms);
    }
    
    /**
     * return the number of changes from the last statement.
     *
     * @return the number of changes from the last statement.
     */
    public int last_changes() {
	return DB.Changes(thedb);
    }

    /**
     * Encapsulates the statement in a query object.
     *
     * @return null of the statememnt is invalid, otherwise
     *      a reference to a sqlite.Query instance.
     */
    public Query make_query(String stmt) {
	SqliteQuery query = DB.MakeQuery(thedb, stmt);
	if (query == null) return null;
	else return new Query(query);
    }

    /** <p>Transforms the string to a quotable form, by doubling the
       internal single quotes only.</p>
       
       <p>See {@link sqlite.Sqlite#QUOTE_string(java.lang.String)}
       for adding quotes around the string as well.</p>

       @param str input string.
       @return transformed string.
     */
    public static String quote_string(String str) {
	if (str == null) return null;
	StringBuffer result = new StringBuffer("");
	int n = str.length();
	for (int i = 0; i < n; i++) {
	    char c = str.charAt(i);
	    result.append(c);
	    if (c == '\'') result.append(c);
	}
	return result.toString();
    }


    /**
       Transforms the string to a quotable form, by doubling the
       internal single quotes, and adding quotes around the result.

       <p>See {@link sqlite.Sqlite#quote_string(java.lang.String)} for
       quoting only the content of the string.</p>

       @param str input string.
       @return transformed string.
     */
    public static String QUOTE_string(String str) {
	if (str == null) return null;
	StringBuffer result = new StringBuffer("");
	result.append("'").append(quote_string(str)).append("'");
	return result.toString();
    }

    /**
       Perform substitutions on the input string, using the Properties
       object to look up variable names.

       <p>Patterns have the form '@NAME@', '@NAME:options@',
       '@NAME:options:quoting@'.</p>

       <p>Each option is a one character spec; the specs are:</p>
       <ul>
       <li>'T'=trim leading and trailing spaces;</li>
       <li>'N'=normalize spaces (any non empty sequence of spaces is
       replaced by one space);</li>
       <li>'L'=turn to lower case;</li> 
       <li>'U'=turn to upper case;</li>
       <li>'D'= replace null with an empty string;</li>
       <li>'n'= replace null with 0 (numeric zero).</li>
       </ul>

       <p>The 'quoting' spec is either 'Q' (call QUOTE_string on
       transformed value), or 'q' (call quote_string on transformed
       value).</p>

       <p>The sequence '@@' is mapped to '@'.</p>

       @param stmt input string.
       @param mapping lookup table, maps NAME patterns to strings.

       @return transformed string.
     */
    public static String format_statement(String stmt, Properties mapping) {
	if (stmt == null) return null;
	if (mapping == null) return stmt;

	int n = stmt.length();
	StringBuffer result = new StringBuffer("");
	int i = 0;
	while (i < n) {
	    if (stmt.startsWith("@@", i)) {
		result.append('@');
		i += 2;
	    }
	    else if (!stmt.startsWith("@", i)) {
		result.append(stmt.charAt(i));
		i++;
	    }
	    else {
		String pattern = "";
		int nextidx = stmt.indexOf('@', i+1);
		if (nextidx == -1) {
		    result.append(stmt.substring(i));
		    i = n;
		    continue;
		}
		else {
		    pattern = stmt.substring(i+1, nextidx);
		    i = nextidx+1;
		}

		String[] args = pattern.split(":");
		String name = args[0];
		String options = (args.length > 1)? args[1] : "";
		String quoting = (args.length > 2)? args[2] : "";
		String value = mapping.getProperty(name);

		int optlen = options.length();
		for (int j = 0; j < optlen; j++) {
		    switch (options.charAt(j)) {
		    case 'L': 
			value = (value == null) ? null : value.toLowerCase();
			break;
		    case 'U':
			value = (value == null) ? null : value.toUpperCase();
			break;
		    case 'T':
			value = (value == null) ? null : value.trim();
			break;
		    case 'N':
			value = (value == null) ? null : value.replaceAll("\\s+", " ");
			break;
		    case 'D':
			value = (value == null) ? "" : value;
			break;
		    case 'n':
			value = (value == null) ? "0" : value;
			break;
		    default:
			break;
		    }
		}
		if (value != null) {
		    if (quoting.startsWith("Q"))
			value = QUOTE_string(value);
		    else if (quoting.startsWith("q"))
			value = quote_string(value);
		}
		result.append(value == null? "" : value);
	    }
	}
	return result.toString();
    }

    /**
     * name of the database file.
     */
    protected String   filename;

    /**
     * the low level database object.
     */
    protected SqliteDB thedb;

    static {
	System.loadLibrary("SqliteDB_java");
    }
}
